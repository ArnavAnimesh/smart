import React from 'react';

import { RiRocketLine, RiLogoutBoxLine } from 'react-icons/ri';

const EntrepreneurNavbar = ({ userName = "Entrepreneur User" }) => {

    return (
        <nav className="bg-[#1E3A5F] text-white px-6 py-3 flex items-center justify-between shadow-md font-sans">

            {/* Logo Section - PRD 4.3.1 */}
            <div className="flex items-center gap-2">
                <RiRocketLine className="text-2xl" />
                <span className="text-xl font-bold tracking-tight">STARTUPNEST</span>
            </div>

            {/* Right Side Items */}
            <div className="flex items-center gap-6">

                {/* User Badge Pill - PRD 10 */}
                <div className="bg-[#2D5282] px-4 py-1.5 rounded-full text-sm font-medium border border-blue-400/30">

                    {userName} / <span className="opacity-80">Entrepreneur</span>
                </div>

                {/* Navigation Links */}
                <div className="flex items-center gap-6 text-sm font-medium">
                    <a href="#" className="hover:text-orange-400 transition-colors">Home</a>
                    <a href="#" className="hover:text-orange-400 transition-colors">Mentor Opportunities</a>
                    <a href="#" className="hover:text-orange-400 transition-colors">My Submissions</a>
                </div>

                {/* Logout Button - PRD 10 */}
                <button className="bg-[#F97316] hover:bg-[#EA6C0A] text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-bold transition-all shadow-sm">
                    <RiLogoutBoxLine /> Logout
                </button>
            </div>
        </nav>

    );

};

export default EntrepreneurNavbar;
