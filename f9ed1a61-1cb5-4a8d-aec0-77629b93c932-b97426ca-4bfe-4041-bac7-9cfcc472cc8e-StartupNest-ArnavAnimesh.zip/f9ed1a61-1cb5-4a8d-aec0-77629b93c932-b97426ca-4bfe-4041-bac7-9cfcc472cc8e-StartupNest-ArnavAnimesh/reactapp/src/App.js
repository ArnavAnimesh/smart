import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Import the components we created
import Login from './Components/Login';
import HomePage from './Components/HomePage';
import Signup from './Components/Signup';
import MentorNavbar from './MentorComponents/MentorNavbar';
import EntrepreneurNavbar from './EntrepreneurComponents/EntrepreneurNavbar';

// --- THE SECURITY GUARD (PrivateRoute) ---
// This checks if the user is logged in before letting them see the Home page.
const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem('token');
  
  // If there is no token (the "passport"), send them back to Login
  if (!token) {
    return <Navigate to="/login" />;
  }
  
  // If token exists, show the children (HomePage)
  return children;
};

// --- PLACEHOLDER COMPONENTS ---
// Since we don't have these files yet, we create "placeholder" 
// functions so the app doesn't crash when you click the links.
const SignupPlaceholder = () => (
  <div className="flex items-center justify-center h-screen bg-slate-100 font-bold">
    Signup Page is under construction. <a href="/login" className="ml-2 text-blue-600 underline">Back to Login</a>
  </div>
);

const ForgotPasswordPlaceholder = () => (
  <div className="flex items-center justify-center h-screen bg-slate-100 font-bold">
    Forgot Password Page is under construction. <a href="/login" className="ml-2 text-blue-600 underline">Back to Login</a>
  </div>
);

function App() {
  return (
    <Router>
      <MentorNavbar/>
      {/* <EntrepreneurNavbar/> */}
      <Routes>
        {/* 1. PUBLIC ROUTES: Anyone can visit these */}
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPasswordPlaceholder />} />

        {/* 2. PROTECTED ROUTES: Only logged-in users can visit these */}
        <Route 
          path="/home" 
          element={
            <ProtectedRoute>
              <HomePage />
            </ProtectedRoute>
          } 
        />

        {/* 3. DEFAULT REDIRECTS: 
            - If they visit exactly "/", go to Login
            - If they type a URL that doesn't exist, go to Login
        */}
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;