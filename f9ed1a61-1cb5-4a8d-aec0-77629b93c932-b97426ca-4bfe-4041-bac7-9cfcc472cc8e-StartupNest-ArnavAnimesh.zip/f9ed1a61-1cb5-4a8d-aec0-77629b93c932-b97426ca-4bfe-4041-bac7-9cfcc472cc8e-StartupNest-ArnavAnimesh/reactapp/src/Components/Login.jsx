import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { RiRocketLine } from 'react-icons/ri';
import axios from 'axios'
// import Loader from './Loader';
 
const Login = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState('');
  const navigate = useNavigate();
 
  // Regex patterns defined locally per instruction
  const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const PASSWORD_REGEX = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
 
  const validate = () => {
    const errs = {};
    if (!EMAIL_REGEX.test(formData.email)) errs.email = 'Invalid email format';
    if (!formData.password) errs.password = 'Password is required';
    else if (!PASSWORD_REGEX.test(formData.password)) {
      errs.password = 'Min 8 chars, 1 uppercase, 1 digit, 1 special char';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };
 
  const handleLogin = async (e) => {
    e.preventDefault();
    if (!validate()) return;
 
    setIsLoading(true);
    setApiError('');
 
    
   
    try {
      const response = await axios.post('https://8080-afabbcdfebdebabbaafadadbabcabfebaccfcccce.premiumproject.examly.io/user/login', formData);
      if (response.data.success) {
        // Update Redux state
        // dispatch(setAuth({
        //   token: response.data.data.token,
        //   user: response.data.data.userName,
        //   role: response.data.data.role
        // }));
        // Persist to localStorage per PRD 4.1.2
        localStorage.setItem('token', response.data.data.token);
        navigate('/home');
      }
    } catch (err) {
      setApiError(err.response?.data?.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
   
    
 
 
  };
 
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-4 font-inter">
      <div className="bg-white rounded-2xl shadow-xl border border-[#E2E8F0] w-full max-w-md overflow-hidden">
        <div className="bg-[#1E3A5F] p-8 text-center">
          <RiRocketLine className="text-[#F97316] text-5xl mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white tracking-tight">StartupNest</h1>
          <p className="text-[#DBEAFE] text-sm mt-2">Empowering ideas, one startup at a time.</p>
        </div>
 
        <div className="p-8">
          <h2 className="text-xl font-bold text-[#1A202C] mb-6">Login to your account</h2>
         
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-[#4A5568] mb-1">Email *</label>
              <input
                type="email"
                placeholder="Enter email"
                className={`w-full rounded-lg border ${errors.email ? 'border-[#B91C1C]' : 'border-[#E2E8F0]'} px-4 py-2.5 focus:ring-2 focus:ring-[#1E3A5F] outline-none transition`}
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
              {errors.email && <p className="text-xs text-[#B91C1C] mt-1">{errors.email}</p>}
            </div>
 
            <div>
              <label className="block text-sm font-medium text-[#4A5568] mb-1">Password *</label>
              <input
                type="password"
                placeholder="Enter password"
                className={`w-full rounded-lg border ${errors.password ? 'border-[#B91C1C]' : 'border-[#E2E8F0]'} px-4 py-2.5 focus:ring-2 focus:ring-[#1E3A5F] outline-none transition`}
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              />
              {errors.password && <p className="text-xs text-[#B91C1C] mt-1">{errors.password}</p>}
            </div>
 
            {apiError && <p className="text-sm text-[#B91C1C] text-center font-medium">{apiError}</p>}
 
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-[#1E3A5F] text-white hover:bg-[#2D5282] rounded-lg px-4 py-3 font-bold transition shadow-md disabled:bg-[#E2E8F0] disabled:text-[#94A3B8]"
            >
              {isLoading ? 'Authenticating...' : 'Login'}
            </button>
          </form>
 
          <div className="mt-8 flex flex-col items-center space-y-3 text-sm">
            <Link to="/forgot-password" title="Forgot Password?" className="text-[#1E3A5F] font-semibold hover:underline">
              Forgot Password?
            </Link>
            <p className="text-[#4A5568]">
              New here? <Link to="/signup" className="text-[#1E3A5F] font-bold hover:underline">Create your account</Link>
            </p>
          </div>
        </div>
      </div>
      {/* {isLoading && <Loader />} */}
    </div>
  );
};
 
export default Login;
 