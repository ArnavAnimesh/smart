import React from 'react';

const Button = ({ variant = "primary", block, children, ...props }) => {
  const variants = {
    primary: "bg-[#1E3A5F] text-white hover:bg-[#2D5282]",
    accent: "bg-[#F97316] text-white hover:bg-[#EA6C0A]"
  };

  return (
    <button 
      className={`py-2.5 px-6 rounded-lg font-bold transition-all active:scale-95 disabled:opacity-50 
      ${variants[variant]} ${block ? 'w-full' : ''}`}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;