import React from 'react';

const Input = ({ label, type = "text", error, ...props }) => (
  <div className="w-full flex flex-col gap-1">
    <label className="text-sm font-semibold text-slate-700">
      {label} <span className="text-red-500">*</span>
    </label>
    <input 
      type={type} 
      className={`w-full border-2 rounded-lg px-4 py-2 outline-none transition-all
        focus:border-primary focus:ring-2 focus:ring-primary/20
        ${error ? 'border-red-500 bg-red-50' : 'border-slate-200 bg-white'}`}
      {...props} 
    />
    {error && <p className="text-xs text-red-600 font-medium">{error}</p>}
  </div>
);

export default Input;