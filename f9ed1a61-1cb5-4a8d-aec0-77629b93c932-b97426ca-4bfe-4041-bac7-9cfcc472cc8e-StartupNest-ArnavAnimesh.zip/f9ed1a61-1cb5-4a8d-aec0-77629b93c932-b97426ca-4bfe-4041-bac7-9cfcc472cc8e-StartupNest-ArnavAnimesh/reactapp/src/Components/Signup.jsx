import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { RiRocketLine, RiCheckLine } from 'react-icons/ri';
import axios from 'axios'
// import Loader from './Loader';
 
const Signup = () => {
  const [formData, setFormData] = useState({
    userName: '',
    email: '',
    mobile: '',
    password: '',
    confirmPassword: '',
    role: '',
    securityAnswer:''
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [apiError,setApiError]=useState('')
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const navigate = useNavigate();
 
  // Regex patterns defined locally per PRD 4.1.1
  const USERNAME_REGEX = /^[a-zA-Z0-9_]{3,}$/;
  const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const MOBILE_REGEX = /^[6-9]\d{9}$/;
  const PASSWORD_REGEX = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
 
  const validate = () => {
    const errs = {};
    if (!USERNAME_REGEX.test(formData.userName)) errs.userName = 'Min 3 chars, alphanumeric & underscore only';
    if (!EMAIL_REGEX.test(formData.email)) errs.email = 'Enter a valid email address';
    if (!MOBILE_REGEX.test(formData.mobile)) errs.mobile = 'Enter a valid 10-digit mobile number';
    if (!PASSWORD_REGEX.test(formData.password)) errs.password = 'Min 8 chars, 1 uppercase, 1 digit, 1 special char';
    if (formData.confirmPassword !== formData.password) errs.confirmPassword = 'Passwords do not match';
    if (!formData.role) errs.role = 'Please select a role';
    if(!formData.securityAnswer) errs.securityAnswer='Please select a securityAnswer'
   
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };
 
  const handleSignup = async (e) => {
    e.preventDefault();
    if (!validate()) return;
 
    setIsLoading(true);
 
    
   
    try {
      const response = await axios.post('https://8080-afabbcdfebdebabbaafadadbabcabfebaccfcccce.premiumproject.examly.io/user/signup', formData);
      if (response.data.success) {
        setShowSuccessModal(true);

      }
      // localStorage.setItem('token', response.data.data.token);


    } catch (err) {
      setApiError(err.response?.data?.message || 'Registration failed');
    } finally {
      setIsLoading(false);
    }

  };
 
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-4 py-12 font-inter">
      <div className="bg-white rounded-2xl shadow-xl border border-[#E2E8F0] w-full max-w-lg overflow-hidden">
       
        {/* Header Section */}
        <div className="bg-[#1E3A5F] p-6 text-center">
          <RiRocketLine className="text-[#F97316] text-4xl mx-auto mb-2" />
          <h1 className="text-xl font-bold text-white uppercase tracking-widest">StartupNest</h1>
          <p className="text-[#DBEAFE] text-xs">Join our ecosystem of innovators and mentors</p>
        </div>
 
        <div className="p-8">
          <h2 className="text-2xl font-bold text-[#1A202C] mb-6 text-center">Create Account</h2>
         
          <form onSubmit={handleSignup} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Username */}
              <div>
                <label className="block text-xs font-bold text-[#4A5568] uppercase mb-1">User Name *</label>
                <input
                  type="text"
                  placeholder="e.g. john_doe"
                  className={`w-full rounded-lg border ${errors.userName ? 'border-[#B91C1C]' : 'border-[#E2E8F0]'} px-4 py-2 text-sm focus:ring-2 focus:ring-[#1E3A5F] outline-none transition`}
                  value={formData.userName}
                  onChange={(e) => setFormData({ ...formData, userName: e.target.value })}
                />
                {errors.userName && <p className="text-[10px] text-[#B91C1C] mt-1 font-medium">{errors.userName}</p>}
              </div>
 
              {/* Mobile */}
              <div>
                <label className="block text-xs font-bold text-[#4A5568] uppercase mb-1">Mobile Number *</label>
                <input
                  type="text"
                  placeholder="10-digit number"
                  className={`w-full rounded-lg border ${errors.mobile ? 'border-[#B91C1C]' : 'border-[#E2E8F0]'} px-4 py-2 text-sm focus:ring-2 focus:ring-[#1E3A5F] outline-none transition`}
                  value={formData.mobile}
                  onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                />
                {errors.mobile && <p className="text-[10px] text-[#B91C1C] mt-1 font-medium">{errors.mobile}</p>}
              </div>
            </div>
 
            {/* Email */}
            <div>
              <label className="block text-xs font-bold text-[#4A5568] uppercase mb-1">Email *</label>
              <input
                type="email"
                placeholder="email@example.com"
                className={`w-full rounded-lg border ${errors.email ? 'border-[#B91C1C]' : 'border-[#E2E8F0]'} px-4 py-2 text-sm focus:ring-2 focus:ring-[#1E3A5F] outline-none transition`}
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
              {errors.email && <p className="text-[10px] text-[#B91C1C] mt-1 font-medium">{errors.email}</p>}
            </div>
 
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Password */}
              <div>
                <label className="block text-xs font-bold text-[#4A5568] uppercase mb-1">Password *</label>
                <input
                  type="password"
                  placeholder="••••••••"
                  className={`w-full rounded-lg border ${errors.password ? 'border-[#B91C1C]' : 'border-[#E2E8F0]'} px-4 py-2 text-sm focus:ring-2 focus:ring-[#1E3A5F] outline-none transition`}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
                {errors.password && <p className="text-[10px] text-[#B91C1C] mt-1 font-medium">{errors.password}</p>}
              </div>
 
              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-bold text-[#4A5568] uppercase mb-1">Confirm Password *</label>
                <input
                  type="password"
                  placeholder="••••••••"
                  className={`w-full rounded-lg border ${errors.confirmPassword ? 'border-[#B91C1C]' : 'border-[#E2E8F0]'} px-4 py-2 text-sm focus:ring-2 focus:ring-[#1E3A5F] outline-none transition`}
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                />
                {errors.confirmPassword && <p className="text-[10px] text-[#B91C1C] mt-1 font-medium">{errors.confirmPassword}</p>}
              </div>
            </div>
 
            {/* Role Selector */}
            <div>
              <label className="block text-xs font-bold text-[#4A5568] uppercase mb-1">Select Role *</label>
              <select
                className={`w-full rounded-lg border ${errors.role ? 'border-[#B91C1C]' : 'border-[#E2E8F0]'} px-4 py-2 text-sm focus:ring-2 focus:ring-[#1E3A5F] outline-none transition bg-white`}
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
              >
                <option value="">Choose your role</option>
                <option value="Entrepreneur">Entrepreneur</option>
                <option value="Mentor">Mentor</option>
              </select>
              {errors.role && <p className="text-[10px] text-[#B91C1C] mt-1 font-medium">{errors.role}</p>}
            </div>


            <div>
              <label className="block text-xs font-bold text-[#4A5568] uppercase mb-1">Security Answer *</label>
              <input
                className={`w-full rounded-lg border ${errors.securityAnswer ? 'border-[#B91C1C]' : 'border-[#E2E8F0]'} px-4 py-2 text-sm focus:ring-2 focus:ring-[#1E3A5F] outline-none transition bg-white`}
                value={formData.securityAnswer}
                onChange={(e) => setFormData({ ...formData, securityAnswer: e.target.value })}
              />
              {errors.securityAnswer && <p className="text-[10px] text-[#B91C1C] mt-1 font-medium">{errors.securityAnswer}</p>}
            </div>
 
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-[#1E3A5F] text-white hover:bg-[#2D5282] rounded-lg px-4 py-3 font-bold text-sm transition shadow-md active:scale-95 disabled:bg-[#E2E8F0] disabled:text-[#94A3B8] mt-4"
            >
              {isLoading ? 'Creating Account...' : 'Submit'}
            </button>
          </form>
 
          <div className="mt-6 text-center text-sm">
            <p className="text-[#4A5568]">
              Already have an account? <Link to="/login" className="text-[#1E3A5F] font-bold hover:underline">Login</Link>
            </p>
          </div>
        </div>
      </div>
 
      {/* Success Modal (PRD 4.1.1 Returns Success Popup) */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[10000] p-4">
          <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-2xl border border-[#E2E8F0] animate-in fade-in zoom-in duration-300">
            <div className="w-20 h-20 bg-[#DCFCE7] rounded-full flex items-center justify-center mx-auto mb-6">
              <RiCheckLine className="text-[#15803D] text-5xl" />
            </div>
            <h3 className="text-2xl font-bold text-[#1A202C] mb-2">User Registration is Successful!</h3>
            <p className="text-[#4A5568] mb-8">You can now access to your new StartupNest account.</p>
            <button
              onClick={() => navigate('/home')}
              className="w-full bg-[#1E3A5F] text-white py-3 rounded-xl font-bold text-lg hover:bg-[#2D5282] transition shadow-lg active:scale-95"
            >
              Ok
            </button>
          </div>
        </div>
      )}
 
      {/* {isLoading && <Loader />} */}
    </div>
  );
};
 
export default Signup;