import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
    const navigate = useNavigate();
    const [showModal, setShowModal] = useState(false);
    
    // Getting data we saved during Login
    const username = localStorage.getItem('username') || "Guest";
    const role = localStorage.getItem('role') || "User";

    const handleLogout = () => {
        localStorage.clear();
        navigate('/login');
    };

    return (
        <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
            {/* Navigation Bar
            <nav className="bg-[#1E3A5F] text-white px-8 py-4 flex justify-between items-center shadow-lg">
                <div className="text-2xl font-black tracking-tight italic">STARTUPNEST</div>
                <div className="flex items-center gap-8">
                    <span className="bg-[#2D5282] px-3 py-1 rounded-full text-xs font-bold uppercase">{username} / {role}</span>
                    <div className="flex gap-6 font-semibold">
                        <span className="cursor-pointer hover:text-[#F97316]" onClick={() => navigate('/home')}>Home</span>
                        {role === 'Mentor' ? 
                            <span className="cursor-pointer hover:text-[#F97316]">Startup Profiles</span> : 
                            <span className="cursor-pointer hover:text-[#F97316]">Opportunities</span>
                        }
                    </div>
                    <button onClick={() => setShowModal(true)} className="bg-[#F97316] px-4 py-2 rounded-lg text-sm font-bold">Logout</button>
                </div>
            </nav> */}

            {/* Banner Section */}
            <div className="relative flex flex-col items-center justify-center p-12 bg-white text-center">
                <div className="bg-[#1E3A5F] text-white p-12 rounded-3xl shadow-2xl max-w-4xl border-t-8 border-[#F97316]">
                    <h2 className="text-5xl font-black mb-4">StartupNest</h2>
                    <p className="text-lg opacity-80 leading-relaxed">Your platform to connect, innovate, and accelerate. Welcome to a space built for collaboration between entrepreneurs and visionaries.</p>
                </div>
            </div>

            {/* Contact Details Card */}
            <div className="flex justify-center p-8">
                <div className="bg-white border-l-8 border-[#1E3A5F] shadow-md p-8 rounded-xl w-full max-w-md">
                    <h3 className="text-2xl font-bold text-[#1E3A5F] mb-4">Contact Support</h3>
                    <div className="text-[#4A5568] space-y-2 font-medium">
                        <p>📞 Phone: +91 98765 43210</p>
                        <p>📧 Email: incubate@startupnest.com</p>
                        <p>📍 Tech City, Innovation Road, IN</p>
                    </div>
                </div>
            </div>

            {/* Simple Logout Confirmation Popup */}
            {showModal && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
                    <div className="bg-white p-8 rounded-2xl shadow-2xl w-full max-w-sm text-center">
                        <p className="text-lg font-bold text-slate-800 mb-6">Are you sure you want to exit?</p>
                        <div className="flex gap-4">
                            <button className="flex-1 bg-red-600 text-white py-2 rounded-lg font-bold" onClick={handleLogout}>Logout</button>
                            <button className="flex-1 bg-slate-200 text-slate-700 py-2 rounded-lg font-bold" onClick={() => setShowModal(false)}>Cancel</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default HomePage;