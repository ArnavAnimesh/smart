import React, { useState } from 'react';

import { RiRocketLine, RiLogoutBoxLine, RiArrowDownSLine } from 'react-icons/ri';
import { useNavigate } from 'react-router-dom';

const MentorNavbar = ({ userName = "Mentor User" }) => {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('role');
        navigate('/login');
    };

    return (
        <nav className="bg-[#1E3A5F] text-white px-6 py-3 flex items-center justify-between shadow-md font-sans">

            {/* Logo Section - PRD 4.2.1 */}
            <div className="flex items-center gap-2">
                <RiRocketLine className="text-2xl" />
                <span className="text-xl font-bold tracking-tight">STARTUPNEST</span>
            </div>

            {/* Right Side Items */}
            <div className="flex items-center gap-6">

                {/* User Badge Pill - PRD 10 (primary-light) */}
                <div className="bg-[#2D5282] px-4 py-1.5 rounded-full text-sm font-medium border border-blue-400/30">

                    {userName} / <span className="opacity-80">Mentor</span>
                </div>

                {/* Navigation Links */}
                <div className="flex items-center gap-6 text-sm font-medium">
                    <a href="#" className="hover:text-orange-400 transition-colors">Home</a>

                    {/* Startup Profiles Dropdown */}
                    <div

                        className="relative cursor-pointer py-2"

                        onMouseEnter={() => setIsDropdownOpen(true)}

                        onMouseLeave={() => setIsDropdownOpen(false)}
                    >
                        <div className="flex items-center gap-1 hover:text-orange-400 transition-colors">

                            Startup Profiles <RiArrowDownSLine />
                        </div>

                        {isDropdownOpen && (
                            <div className="absolute top-full right-0 w-48 bg-white text-gray-800 rounded-md shadow-xl border border-gray-200 py-2 z-50">
                                <a href="#" className="block px-4 py-2 hover:bg-gray-100 transition-colors">Add Profile</a>
                                <a href="#" className="block px-4 py-2 hover:bg-gray-100 transition-colors">View Profiles</a>
                            </div>

                        )}
                    </div>

                    <a href="#" className="hover:text-orange-400 transition-colors">Startup Submissions</a>
                </div>

                {/* Logout Button - PRD 10 (accent color) */}
                <button
                    onClick={handleLogout}
                    className="bg-[#F97316] hover:bg-[#EA6C0A] text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-bold transition-all shadow-sm"
                >
                    <RiLogoutBoxLine /> Logout
                </button>
            </div>
        </nav>

    );

};

export default MentorNavbar;
