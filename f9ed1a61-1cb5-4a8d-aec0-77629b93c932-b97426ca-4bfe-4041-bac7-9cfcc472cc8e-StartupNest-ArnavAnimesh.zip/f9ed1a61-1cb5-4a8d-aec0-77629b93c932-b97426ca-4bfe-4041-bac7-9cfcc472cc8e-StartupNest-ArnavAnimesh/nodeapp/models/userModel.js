const mongoose = require('mongoose');


const userSchema = new mongoose.Schema({
  userName: {
    type: String,
    required: [true, 'Username is required'],
    unique: true,
    trim: true,
    minlength: [3, 'Min 3 characters'],
    match: [/^[a-zA-Z0-9_]{3,}$/, 'Alphanumeric and underscore only']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Invalid email format']
  },
  mobile: {
    type: String,
    required: [true, 'Mobile is required'],
    unique: true,
    match: [/^[6-9]\d{9}$/, 'Enter valid 10-digit mobile number']
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [8, 'Min 8 characters']
   
  },
  role: {
    type: String,
    required: [true, 'Role is required'],
    enum: {
      values: ['Mentor', 'Entrepreneur'],
      message: 'Invalid role'
    }
  },
  
  securityQuestion: {
    type: String,
    required: [true, 'Security question is required'],
    default: "What was the name of your first school?"
  },
  securityAnswer: {
    type: String,
    required: [true, 'Security answer is required']
  
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('User', userSchema);