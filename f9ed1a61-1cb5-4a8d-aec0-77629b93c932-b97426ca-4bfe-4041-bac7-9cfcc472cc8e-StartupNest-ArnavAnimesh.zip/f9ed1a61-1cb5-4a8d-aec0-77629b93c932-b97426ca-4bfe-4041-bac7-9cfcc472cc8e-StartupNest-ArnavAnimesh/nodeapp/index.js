const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

// Import Routers
const userRouter = require('./routers/userRouter');

const app = express();
const PORT = 8080;

// Middlewares
app.use(express.json());
app.use(cors({ origin: true, credentials: true })); // Fixes CORS errors in cloud tools

// MongoDB Connection (PRD Section 11)
mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/startupnest")
    .then(() => console.log("Database Connected"))
    .catch(err => console.error(" DB Connection Error:", err));

// Route Setup (PRD Section 7)
app.use('/user', userRouter);

// Global Error Handler (PRD Section 5.5)
app.use((err, req, res, next) => {
    console.error("Error:", err.message);
    res.status(500).json({ success: false, message: "Server Error occurred" });
});

app.listen(PORT, () => console.log(`Server initialized on Port ${PORT}`));