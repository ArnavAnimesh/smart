const jwt = require('jsonwebtoken'); // Import library to create secret tokens


const generateToken = (payload) => {
    
    return jwt.sign(
        payload, 
        process.env.JWT_SECRET || 'asdfghjkl', 
        { expiresIn: '1h' }
    );
};

const validateToken = (req, res, next) => {

    const authHeader = req.headers.authorization;


    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ success: false, message: 'Stop! You are not logged in.' });
    }

    const token = authHeader.split(' ')[1]; 

    try {
    
        const decodedInfo = jwt.verify(token, process.env.JWT_SECRET || 'asdfghjkl');
     
        req.user = decodedInfo; 
        
        next(); 
    } catch (error) {
        return res.status(401).json({ success: false, message: 'Invalid or expired passport.' });
    }
};



const isMentor = (req, res, next) => {
    if (req.user && req.user.role === 'Mentor') {
        next();
    } else {
        res.status(403).json({ success: false, message: 'Sorry, this area is for Mentors only!' });
    }
};

const isEntrepreneur = (req, res, next) => {
    if (req.user && req.user.role === 'Entrepreneur') {
        next();
    } else {
        res.status(403).json({ success: false, message: 'Sorry, this area is for Entrepreneurs only!' });
    }
};


module.exports = { generateToken, validateToken, isMentor, isEntrepreneur };