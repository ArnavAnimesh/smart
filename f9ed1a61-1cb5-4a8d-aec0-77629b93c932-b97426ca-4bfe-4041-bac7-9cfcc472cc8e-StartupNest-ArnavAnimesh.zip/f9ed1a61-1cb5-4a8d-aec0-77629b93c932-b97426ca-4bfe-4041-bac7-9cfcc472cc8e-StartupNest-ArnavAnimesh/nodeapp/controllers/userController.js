const User = require('../models/userModel');
const bcrypt = require('bcryptjs'); 
const jwt = require('jsonwebtoken'); 
const { generateToken } = require('../authUtils');
exports.signup = async (req, res) => {
  try {
    const { userName, email, mobile, password, role, securityAnswer } = req.body;

    
    const userExists = await User.findOne({ email: email });
    if (userExists) {
      return res.status(400).json({ success: false, message: "Email already exists!" });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);


    const newUser = new User({
      userName,
      email,
      mobile,
      password: hashedPassword,
      role,
      securityAnswer: securityAnswer.toLowerCase() 
    });

    await newUser.save();


    res.status(201).json({ success: true, message: "User registered successfully!" });

  } catch (error) {
    res.status(500).json({ success: false, message: "Signup Error: " + error.message });
  }
};


exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ success: false, message: "Invalid email or password" });
    }

    const isPasswordCorrect = await bcrypt.compare(password, user.password);
    if (!isPasswordCorrect) {
      return res.status(401).json({ success: false, message: "Invalid email or password" });
    }

    
    const token = generateToken({ id: user._id, role: user.role });

    res.status(200).json({
      success: true,
      message: "Welcome back!",
      data: {
        token: token,
        userName: user.userName,
        role: user.role,
        id: user._id
      }
    });

  } catch (error) {
    res.status(500).json({ success: false, message: "Login Error: " + error.message });
  }
};


exports.forgotPassword = async (req, res) => {
  try {
    const { email, securityAnswer, newPassword } = req.body;

 
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }


    if (user.securityAnswer !== securityAnswer.toLowerCase()) {
      return res.status(400).json({ success: false, message: "Incorrect security answer" });
    }

    
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(newPassword, salt);
    await user.save();

    res.status(200).json({ success: true, message: "Password updated successfully!" });

  } catch (error) {
    res.status(500).json({ success: false, message: "Reset Error: " + error.message });
  }
};